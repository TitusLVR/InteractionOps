<a href="https://imgur.com/bUoowcQ"><img src="https://i.imgur.com/bUoowcQ.png" title="iOps" /></a>

# InteractionOps or iOps
  It is a set of operators which boost Blender interactivity between user and application by using only five functional buttons. 

## Documentation:
https://interactionops-docs.readthedocs.io/en/latest/index.html
   
## Ideas and support:
BlenderArtists forum page 
https://blenderartists.org/t/interactionops-iops/

## Authors:
Cyrill Vitkovskiy:
https://www.artstation.com/furash

Titus Lavrov:
https://www.artstation.com/tituslvr
Also check my page on gumroad: 
https://gumroad.com/titus

## Special thanks:
For author of qBlocker
https://gumroad.com/sanislovart

jayanamgames youtube channel:
https://www.youtube.com/user/jayanamgames

Many thanks!


